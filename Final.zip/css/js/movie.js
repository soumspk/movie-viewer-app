//Javascript Document
//Javascript Array
var movies = [{
	title: "Jurassic Park",
	overview: "In Steven Spielberg's massive blockbuster, paleontologists Alan Grant (Sam Neill) and Ellie Sattler (Laura Dern) and mathematician Ian Malcolm (Jeff Goldblum) are among a select group chosen to tour an island theme park populated by dinosaurs created from prehistoric DNA. While the park's mastermind, billionaire John Hammond (Richard Attenborough), assures everyone that the facility is safe, they find out otherwise when various ferocious predators break free and go on the hunt.In Steven Spielberg's massive blockbuster, paleontologists Alan Grant (Sam Neill) and Ellie Sattler (Laura Dern) and mathematician Ian Malcolm (Jeff Goldblum) are among a select group chosen to tour an island theme park populated by dinosaurs created from prehistoric DNA. While the park's mastermind, billionaire John Hammond (Richard Attenborough), assures everyone that the facility is safe, they find out otherwise when various ferocious predators break free and go on the hunt.In Steven Spielberg's massive blockbuster, paleontologists Alan Grant (Sam Neill) and Ellie Sattler (Laura Dern) and mathematician Ian Malcolm (Jeff Goldblum) are among a select group chosen to tour an island theme park populated by dinosaurs created from prehistoric DNA. While the park's mastermind, billionaire John Hammond (Richard Attenborough), assures everyone that the facility is safe, they find out otherwise when various ferocious predators break free and go on the hunt. In Steven Spielberg's massive blockbuster, paleontologists Alan Grant (Sam Neill) and Ellie Sattler (Laura Dern) and mathematician Ian Malcolm (Jeff Goldblum) are among a select group chosen to tour an island theme park populated by dinosaurs created from prehistoric DNA. While the park's mastermind, billionaire John Hammond (Richard Attenborough), assures everyone that the facility is safe, they find out otherwise when various ferocious predators break free and go on the hunt.In Steven Spielberg's massive blockbuster, paleontologists Alan Grant (Sam Neill) and Ellie Sattler (Laura Dern) and mathematician Ian Malcolm (Jeff Goldblum) are among a select group chosen to tour an island theme park populated by dinosaurs created from prehistoric DNA. While the park's mastermind, billionaire John Hammond (Richard Attenborough), assures everyone that the facility is safe, they find out otherwise when various ferocious predators break free and go on the hunt.",
	image: "images/thumbnail/jurassic-park.jpg",
	actors: [{
		fullName: "Jeff Goldblum",
		roleDesc: "Jeffrey Lynn Goldblum is an American actor and musician. He has starred in some of the highest-grossing films of his era, Jurassic Park and Independence Day, as well as their respective sequels, The Lost World: Jurassic Park and Jurassic World: Fallen Kingdom, and Independence Day: Resurgence.",
		displayPic: "images/cast/jurassic-park/j-img-1.jpg"
	}, {
		fullName: "Sam Neil",
		roleDesc: "Nigel John Dermot Neill DCNZM OBE (born 14 September 1947), known professionally as Sam Neill, is a New Zealand actor, writer, producer, director, and vineyard owner. Born in Omagh, Northern Ireland, he moved to Christchurch with his family in 1954.",
		displayPic: "images/cast/jurassic-park/j-img-2.jpg"
	}],
	slider: [{
		movieBanner0: "images/slider/jp/j1.jpg",
		movieBanner1: "images/slider/jp/j2.jpg",
		movieBanner2: "images/slider/jp/j1.jpg",
		movieBanner3: "images/slider/jp/j2.jpg",
		movieBanner4: "images/slider/jp/j1.jpg",
		movieBanner5: "images/slider/jp/j2.jpg"
	}]
}, {
	title: "Notting Hill",
	overview: "William Thacker (Hugh Grant) is a London bookstore owner whose humdrum existence is thrown into romantic turmoil when famous American actress Anna Scott (Julia Roberts) appears in his shop. A chance encounter over spilled orange juice leads to a kiss that blossoms into a full-blown affair. As the average bloke and glamorous movie star draw closer and closer together, they struggle to reconcile their radically different lifestyles in the name of love. William Thacker (Hugh Grant) is a London bookstore owner whose humdrum existence is thrown into romantic turmoil when famous American actress Anna Scott (Julia Roberts) appears in his shop. A chance encounter over spilled orange juice leads to a kiss that blossoms into a full-blown affair. As the average bloke and glamorous movie star draw closer and closer together, they struggle to reconcile their radically different lifestyles in the name of love.William Thacker (Hugh Grant) is a London bookstore owner whose humdrum existence is thrown into romantic turmoil when famous American actress Anna Scott (Julia Roberts) appears in his shop. A chance encounter over spilled orange juice leads to a kiss that blossoms into a full-blown affair. As the average bloke and glamorous movie star draw closer and closer together, they struggle to reconcile their radically different lifestyles in the name of love. William Thacker (Hugh Grant) is a London bookstore owner whose humdrum existence is thrown into romantic turmoil when famous American actress Anna Scott (Julia Roberts) appears in his shop. A chance encounter over spilled orange juice leads to a kiss that blossoms into a full-blown affair. As the average bloke and glamorous movie star draw closer and closer together, they struggle to reconcile their radically different lifestyles in the name of love. William Thacker (Hugh Grant) is a London bookstore owner whose humdrum existence is thrown into romantic turmoil when famous American actress Anna Scott (Julia Roberts) appears in his shop. A chance encounter over spilled orange juice leads to a kiss that blossoms into a full-blown affair. As the average bloke and glamorous movie star draw closer and closer together, they struggle to reconcile their radically different lifestyles in the name of love.William Thacker (Hugh Grant) is a London bookstore owner whose humdrum existence is thrown into romantic turmoil when famous American actress Anna Scott (Julia Roberts) appears in his shop. A chance encounter over spilled orange juice leads to a kiss that blossoms into a full-blown affair. As the average bloke and glamorous movie star draw closer and closer together, they struggle to reconcile their radically different lifestyles in the name of love.",
	image: "images/thumbnail/notting-hill.jpg",
	actors: [{
		fullName: "Hugh Grant",
		roleDesc: "Hugh John Mungo Grant (born 9 September 1960) is an English actor and film producer. Grant has received a Golden Globe, a BAFTA, and an Honorary César for his work. As of 2018, his films have grossed a total of nearly US$3 billion worldwide from 29 theatrical releases.",
		displayPic: "images/cast/notting-hill/no-img-1.jpg"
	}, {
		fullName: "Julia Roberts",
		roleDesc: "Julia Fiona Roberts (born October 28, 1967) is an American actress and producer. She became a Hollywood star after headlining the romantic comedy Pretty Woman (1990), which grossed $464 million worldwide.",
		displayPic: "images/cast/notting-hill/no-img-2.jpg"
	}],
	slider: [{
		movieBanner0: "images/slider/nh/nh-1.jpg",
		movieBanner1: "images/slider/nh/nh-2.jpg",
		movieBanner2: "images/slider/nh/nh-1.jpg",
		movieBanner3: "images/slider/nh/nh-2.jpg",
		movieBanner4: "images/slider/nh/nh-1.jpg",
		movieBanner5: "images/slider/nh/nh-2.jpg",
		movieBanner6: "images/slider/nh/nh-1.jpg"
	}]
}, {
	title: "Home Alone",
	overview: "When bratty 8-year-old Kevin McCallister (Macaulay Culkin) acts out the night before a family trip to Paris, his mother (Catherine O'Hara) makes him sleep in the attic. After the McCallisters mistakenly leave for the airport without Kevin, he awakens to an empty house and assumes his wish to have no family has come true. But his excitement sours when he realizes that two con men (Joe Pesci, Daniel Stern) plan to rob the McCallister residence, and that he alone must protect the family home.When bratty 8-year-old Kevin McCallister (Macaulay Culkin) acts out the night before a family trip to Paris, his mother (Catherine O'Hara) makes him sleep in the attic. After the McCallisters mistakenly leave for the airport without Kevin, he awakens to an empty house and assumes his wish to have no family has come true. But his excitement sours when he realizes that two con men (Joe Pesci, Daniel Stern) plan to rob the McCallister residence, and that he alone must protect the family home.When bratty 8-year-old Kevin McCallister (Macaulay Culkin) acts out the night before a family trip to Paris, his mother (Catherine O'Hara) makes him sleep in the attic. After the McCallisters mistakenly leave for the airport without Kevin, he awakens to an empty house and assumes his wish to have no family has come true. But his excitement sours when he realizes that two con men (Joe Pesci, Daniel Stern) plan to rob the McCallister residence, and that he alone must protect the family home.When bratty 8-year-old Kevin McCallister (Macaulay Culkin) acts out the night before a family trip to Paris, his mother (Catherine O'Hara) makes him sleep in the attic. After the McCallisters mistakenly leave for the airport without Kevin, he awakens to an empty house and assumes his wish to have no family has come true. But his excitement sours when he realizes that two con men (Joe Pesci, Daniel Stern) plan to rob the McCallister residence, and that he alone must protect the family home.",
	image: "images/thumbnail/home-alone.jpg",
	actors: [{
		fullName: "Macaulay Culkin",
		roleDesc: "Macaulay Macaulay Culkin Culkin (born Macaulay Carson Culkin, August 26, 1980) is an American actor and musician who began his career as a child actor, and is best known for his role as Kevin McCallister in the Christmas films Home Alone (1990), for which he was nominated for a Golden Globe Award for Best Actor ",
		displayPic: "images/cast/home-alone/home-1.jpg"
	}, {
		fullName: "Joe Pesci",
		roleDesc: "Joseph Frank Pesci is an American actor, comedian and singer who is known for portraying tough, volatile characters in a variety of genres",
		displayPic: "images/cast/home-alone/home-2.jpg"
	}],
	slider: [{
		movieBanner0: "images/slider/ha/ha1.jpg",
		movieBanner1: "images/slider/ha/ha2.jpg",
		movieBanner2: "images/slider/ha/ha1.jpg",
		movieBanner3: "images/slider/ha/ha2.jpg",
		movieBanner4: "images/slider/ha/ha1.jpg",
		movieBanner5: "images/slider/ha/ha2.jpg",
		movieBanner6: "images/slider/ha/ha1.jpg"
	}]
}, {
	title: "Hunger Game",
	overview: "In what was once North America, the Capitol of Panem its hold on its 12 districts by forcing them each to select a boy and a girl, called Tributes, to compete in a nationally televised event called the Hunger Games. Every citizen must watch as the youths fight to the death until only one remains. District 12 Tribute Katniss Everdeen (Jennifer Lawrence) has little to rely on, other than her hunting skills and sharp instincts, in an arena where she must weigh survival against love.In what was once North America, the Capitol of Panem maintains its hold on its 12 districts by forcing them each to select a boy and a girl, called Tributes, to compete in a nationally televised event called the Hunger Games. Every citizen must watch as the youths fight to the death until only one remains. District 12 Tribute Katniss Everdeen (Jennifer Lawrence) has little to rely on, other than her hunting skills and sharp instincts, in an arena where she must weigh survival against love.In what was once North America, the Capitol of Panem maintains its hold on its 12 districts by forcing them each to select a boy and a girl, called Tributes, to compete in a nationally televised event called the Hunger Games. Every citizen must watch as the youths fight to the death until only one remains. District 12 Tribute Katniss Everdeen (Jennifer Lawrence) has little to rely on, other than her hunting skills and sharp instincts, in an arena where she must weigh survival against love.In what was once North America, the Capitol of Panem maintains its hold on its 12 districts by forcing them each to select a boy and a girl, called Tributes, to compete in a nationally televised event called the Hunger Games. Every citizen must watch as the youths fight to the death until only one remains. District 12 Tribute Katniss Everdeen (Jennifer Lawrence) has little to rely on, other than her hunting skills and sharp instincts, in an arena where she must weigh survival against love.",
	image: "images/thumbnail/hunger-game.jpg",
	actors: [{
		fullName: "Jennifer Lawrence",
		roleDesc: "Jennifer Shrader Lawrence (born August 15, 1990) is an American actress. Her films have grossed over $5.7 billion worldwide, and she was the highest-paid actress in the world in 2015 and 2016.",
		displayPic: "images/cast/hunger-game/hg-1.jpg"
	}, {
		fullName: "Josh Hutcherson",
		roleDesc: "Joshua Ryan Hutcherson (born October 12, 1992) is an American actor and producer. Hutcherson began his acting career in the early 2000s",
		displayPic: "images/cast/hunger-game/hg-2.jpg"
	}],
	slider: [{
		movieBanner0: "images/slider/hg/hg1.jpg",
		movieBanner1: "images/slider/hg/hg2.jpg",
		movieBanner2: "images/slider/hg/hg1.jpg",
		movieBanner3: "images/slider/hg/hg2.jpg",
		movieBanner4: "images/slider/hg/hg1.jpg",
		movieBanner5: "images/slider/hg/hg2.jpg",
		movieBanner6: "images/slider/hg/hg1.jpg"
	}]
}, {
	title: "Terminator",
	overview: "Disguised as a human, a cyborg assassin known as a Terminator (Arnold Schwarzenegger) travels from 2029 to 1984 to kill Sarah Connor (Linda Hamilton). Sent to protect Sarah is Kyle Reese (Michael Biehn), who divulges the coming of Skynet, an artificial intelligence system that will spark a nuclear holocaust. Sarah is targeted because Skynet knows that her unborn son will lead the fight against them. With the virtually unstoppable Terminator in hot pursuit, she and Kyle attempt to escape.Disguised as a human, a cyborg assassin known as a Terminator (Arnold Schwarzenegger) travels from 2029 to 1984 to kill Sarah Connor (Linda Hamilton). Sent to protect Sarah is Kyle Reese (Michael Biehn), who divulges the coming of Skynet, an artificial intelligence system that will spark a nuclear holocaust. Sarah is targeted because Skynet knows that her unborn son will lead the fight against them. With the virtually unstoppable Terminator in hot pursuit, she and Kyle attempt to escape.Disguised as a human, a cyborg assassin known as a Terminator (Arnold Schwarzenegger) travels from 2029 to 1984 to kill Sarah Connor (Linda Hamilton). Sent to protect Sarah is Kyle Reese (Michael Biehn), who divulges the coming of Skynet, an artificial intelligence system that will spark a nuclear holocaust. Sarah is targeted because Skynet knows that her unborn son will lead the fight against them. With the virtually unstoppable Terminator in hot pursuit, she and Kyle attempt to escape.Disguised as a human, a cyborg assassin known as a Terminator (Arnold Schwarzenegger) travels from 2029 to 1984 to kill Sarah Connor (Linda Hamilton). Sent to protect Sarah is Kyle Reese (Michael Biehn), who divulges the coming of Skynet, an artificial intelligence system that will spark a nuclear holocaust. Sarah is targeted because Skynet knows that her unborn son will lead the fight against them. With the virtually unstoppable Terminator in hot pursuit, she and Kyle attempt to escape.Disguised as a human, a cyborg assassin known as a Terminator (Arnold Schwarzenegger) travels from 2029 to 1984 to kill Sarah Connor (Linda Hamilton). Sent to protect Sarah is Kyle Reese (Michael Biehn), who divulges the coming of Skynet, an artificial intelligence system that will spark a nuclear holocaust. Sarah is targeted because Skynet knows that her unborn son will lead the fight against them. With the virtually unstoppable Terminator in hot pursuit, she and Kyle attempt to escape.",
	image: "images/thumbnail/terminator.jpg",
	actors: [{
		fullName: "Arnold Schwarzenegger",
		roleDesc: "Arnold Alois Schwarzenegger (/ˈʃvɑːrtsnɛɡər/; German: [ˈaɐ̯nɔlt ˈʃvaɐ̯tsn̩ˌʔɛɡɐ]; born July 30, 1947) is an Austrian-American actor, filmmaker, businessman, author, philanthropist, activist, politician, and former professional bodybuilder and powerlifter. He served as the 38th Governor of California from 2003 to 2011.",
		displayPic: "images/cast/terminator/terminator-1.jpg"
	}, {
		fullName: "Linda Hamilton",
		roleDesc: "Linda Carroll Hamilton (born September 26, 1956) is an American actress best known for her portrayal of Sarah Connor in The Terminator film series and Catherine Chandler in the television series Beauty and the Beast (1987-1990), for which she was nominated for two Golden Globe Awards and an Emmy Award.",
		displayPic: "images/cast/terminator/terminator-2.jpg"
	}],
	slider: [{
		movieBanner0: "images/slider/tm/tm1.jpg",
		movieBanner1: "images/slider/tm/tm2.jpg",
		movieBanner2: "images/slider/tm/tm1.jpg",
		movieBanner3: "images/slider/tm/tm2.jpg",
		movieBanner4: "images/slider/tm/tm1.jpg",
		movieBanner5: "images/slider/tm/tm2.jpg",
		movieBanner5: "images/slider/tm/tm2.jpg"
	}]
}, {
	title: "The Wizard of Oz",
	overview: "When a tornado rips through Kansas, Dorothy (Judy Garland) and her dog, Toto, are whisked away in their house to the magical land of Oz. They follow the Yellow Brick Road toward the Emerald City to meet the Wizard, and en route they meet a Scarecrow (Ray Bolger) that needs a brain, a Tin Man (Jack Haley) missing a heart, and a Cowardly Lion (Bert Lahr) who wants courage. The wizard asks the group to bring him the broom of the Wicked Witch of the West (Margaret Hamilton) to earn his help.When a tornado rips through Kansas, Dorothy (Judy Garland) and her dog, Toto, are whisked away in their house to the magical land of Oz. They follow the Yellow Brick Road toward the Emerald City to meet the Wizard, and en route they meet a Scarecrow (Ray Bolger) that needs a brain, a Tin Man (Jack Haley) missing a heart, and a Cowardly Lion (Bert Lahr) who wants courage. The wizard asks the group to bring him the broom of the Wicked Witch of the West (Margaret Hamilton) to earn his help.When a tornado rips through Kansas, Dorothy (Judy Garland) and her dog, Toto, are whisked away in their house to the magical land of Oz. They follow the Yellow Brick Road toward the Emerald City to meet the Wizard, and en route they meet a Scarecrow (Ray Bolger) that needs a brain, a Tin Man (Jack Haley) missing a heart, and a Cowardly Lion (Bert Lahr) who wants courage. The wizard asks the group to bring him the broom of the Wicked Witch of the West (Margaret Hamilton) to earn his help.When a tornado rips through Kansas, Dorothy (Judy Garland) and her dog, Toto, are whisked away in their house to the magical land of Oz. They follow the Yellow Brick Road toward the Emerald City to meet the Wizard, and en route they meet a Scarecrow (Ray Bolger) that needs a brain, a Tin Man (Jack Haley) missing a heart, and a Cowardly Lion (Bert Lahr) who wants courage. The wizard asks the group to bring him the broom of the Wicked Witch of the West (Margaret Hamilton) to earn his help.When a tornado rips through Kansas, Dorothy (Judy Garland) and her dog, Toto, are whisked away in their house to the magical land of Oz. They follow the Yellow Brick Road toward the Emerald City to meet the Wizard, and en route they meet a Scarecrow (Ray Bolger) that needs a brain, a Tin Man (Jack Haley) missing a heart, and a Cowardly Lion (Bert Lahr) who wants courage. The wizard asks the group to bring him the broom of the Wicked Witch of the West (Margaret Hamilton) to earn his help.",
	image: "images/thumbnail/the-wizard.jpg",
	actors: [{
		fullName: "Judy Garland",
		roleDesc: "Judy Garland (born Frances Ethel Gumm; June 10, 1922 – June 22, 1969) was an American actress, singer, dancer, and vaudevillian. During a career that spanned 45 years, she attained international stardom as an actress in both musical and dramatic roles, as a recording artist, and on the concert stage.",
		displayPic: "images/cast/wizard-oz/wz-1.jpg"
	}, {
		fullName: "Ray Bolger",
		roleDesc: "Raymond Wallace Bolger (January 10, 1904 – January 15, 1987) was an American film and television actor, vaudevillian, TV presenter, singer, dancer (particularly of tap) and stage performer (particularly musical theatre) ",
		displayPic: "images/cast/wizard-oz/wz-2.jpg"
	}],
	slider: [{
		movieBanner0: "images/slider/wz/wz1.jpg",
		movieBanner1: "images/slider/wz/wz2.jpg",
		movieBanner2: "images/slider/wz/wz1.jpg",
		movieBanner3: "images/slider/wz/wz2.jpg",
		movieBanner4: "images/slider/wz/wz1.jpg",
		movieBanner5: "images/slider/wz/wz2.jpg",
		movieBanner5: "images/slider/wz/wz1.jpg"
	}]
}, {
	title: "The Queen",
	overview: "In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.",
	image: "images/thumbnail/the-queen.jpg",
	actors: [{
		fullName: "Helen Mirren",
		roleDesc: "Dame Helen Lydia Mirren, DBE (née Mironoff; born 26 July 1945) is an English actor. Mirren began her acting career with the Royal Shakespeare Company in 1967, and is one of the few performers who have achieved the Triple Crown of Acting.",
		displayPic: "images/cast/queen/queen-1.jpg"
	}, {
		fullName: "Alex Jennings",
		roleDesc: "Alex Jennings (born 10 May 1957) is an English actor, who has worked extensively with the Royal Shakespeare Company and National Theatre.",
		displayPic: "images/cast/queen/queen-2.jpg"
	}],
	slider: [{
		movieBanner0: "images/slider/tq/tq1.jpg",
		movieBanner1: "images/slider/tq/tq2.jpg",
		movieBanner2: "images/slider/tq/tq1.jpg",
		movieBanner3: "images/slider/tq/tq2.jpg",
		movieBanner4: "images/slider/tq/tq1.jpg",
		movieBanner5: "images/slider/tq/tq2.jpg",
		movieBanner5: "images/slider/tq/tq2.jpg"
	}]
}, {
	title: "Titanic",
	overview: "In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.In the wake of a national tragedy, the prime minister and royal family find themselves quietly at odds. The initial reluctance of Buckingham Palace to mourn Diana is seen by the public as a sign of cool emotional distance, but Tony Blair, perceiving a potential public-relations disaster in the making, takes it upon himself to persuade Queen Elizabeth to pay tribute to the dead princess.",
	image: "images/thumbnail/titanic.jpg",
	actors: [{
		fullName: "Leonardo DiCaprio",
		roleDesc: "Leonardo Wilhelm DiCaprio (/dɪˈkæprioʊ/, Italian: [diˈkaːprjo]; born November 11, 1974) is an American actor, film producer, and environmentalist.",
		displayPic: "images/cast/titanic/tit-1.jpg"
	}, {
		fullName: "Kate Winslet",
		roleDesc: "Kate Elizabeth Winslet, CBE (born 5 October 1975) is an English actress. She is particularly known for her work in period dramas and tragedies, and is often drawn to portraying troubled women.",
		displayPic: "images/cast/titanic/tit-2.jpg"
	}],
	slider: [{
		movieBanner0: "images/slider/tc/tc1.jpg",
		movieBanner1: "images/slider/tc/tc2.jpg",
		movieBanner2: "images/slider/tc/tc1.jpg",
		movieBanner3: "images/slider/tc/tc2.jpg",
		movieBanner4: "images/slider/tc/tc1.jpg",
		movieBanner5: "images/slider/tc/tc2.jpg",
		movieBanner5: "images/slider/tc/tc2.jpg"
	}]
}];
var posters = document.querySelector(".wrapper__movies--column");
var movie = document.querySelector(".wrapper__movies");
var movietemplate = "";
for (var i = 0; i < movies.length; i++) {
	movietemplate += '<div class="wrapper__movies--column--card"><img id="' + i +
		'" class="movie-thumbnail wrapper_movies--column--image" src=' + movies[i].image +
		' height="200" /></div>';
}
posters.innerHTML = movietemplate;
document.addEventListener('click', function(e) {
	if (!event.target.matches('.movie-thumbnail')) return;
	var e = e.target.id;
	window.location.hash = e;
	var navbar = document.querySelector("#navbar");
	var backButton = "";
	var mainTabs =
		'<button class="tablinks overview-btn active" onclick=movieDetails(event,"Overview")>Overview</button><button class="tablinks cast-btn" onclick=movieDetails(event,"Cast")>Cast</button><h3 class="wrapper__back-to-main" onClick="goHome()"><< Back to Collections</h3>';
	navbar.innerHTML = mainTabs;
	var movieHeadline = document.querySelector(".wrapper__title");
	var movieName = movies[e].title;
	var shareImage = document.querySelector(".wrapper__title-icon");
	var sharenews =
		'<img onclick="myShare()" class="wrapper__title-icon-share" src="images/icon/triple.png" width="25" height="25" />';
	shareImage.innerHTML = sharenews;
	var shareIcon = document.querySelector(".wrapper__share");
	var sharefeed = ' <a href="#">Share</a><br><a href="#">Send Feedback</a>';
	shareIcon.innerHTML = sharefeed;
	movieHeadline.innerHTML = movieName;
	var title = "";
	var myslide = "";
	var overview = document.querySelector("#Overview");
	for (z = 0; z < movies[e].slider.length; z++) {
		myslide =
			'<div id="slider"><div id="slide-container"><div class="slide"><img class="myslide" src=' +
			movies[e].slider[z].movieBanner1 +
			' /></div><div class="slide"><img class="myslide" src=' + movies[e].slider[
				z].movieBanner2 + ' /></div><div class="slide"><img class="myslide" src=' +
			movies[e].slider[z].movieBanner3 +
			' /></div><div class="slide"><img class="myslide" src=' + movies[e].slider[
				z].movieBanner4 + ' /></div><div class="slide"><img class="myslide" src=' +
			movies[e].slider[z].movieBanner5 + ' /></div></div></div></div>';
		title = '<br><p class="movie__overview">' + movies[e].overview + '</p>';
	}
	overview.innerHTML = myslide + title;
	if (overview) {
		overview.className += overview.className ? ' active' : ' not-active';
		movie.className += movie.className ? ' not-active' : '';
	}
}, false);
var castPerson = "";
var castPP = document.querySelector("#Cast");
//Overview, Cast Tabs
function openImg(main_id, click_id) {
	castPerson = '<div class="cast__detail"><img class="card__image" src=' +
		movies[main_id].actors[click_id].displayPic +
		' height="200" /><div class="card__title">' + movies[main_id].actors[click_id]
		.fullName + '</div><div class="role__desc">' + movies[main_id].actors[
			click_id].roleDesc + '</div><div id="closeBtn">X</div></div>';
	castPP.innerHTML = castPerson;
}
document.addEventListener('click', function(e) {
	if (!event.target.matches('#closeBtn')) return;
	document.querySelector(".cast-btn").click();
}, false);

function movieDetails(evt, movieDesc) {
	if (window.location.hash) {
		var movieId = location.hash.substr(1);
		var castList = "";
		var cast = document.querySelector("#Cast");
		for (var y = 0; y < movies[movieId].actors.length; y++) {
			castList +=
				'<div class="card__wrapper"><div class="card__info"><img onClick="openImg(' +
				movieId + ',' + y + ')" class="card__image" id="' + y + '"src=' + movies[
					movieId].actors[y].displayPic +
				' height="200" /><div class="card__title">' + movies[movieId].actors[y].fullName +
				'</div></div></div></div></div></div>';
		}
		cast.innerHTML = castList;
		var i, tabcontent, tablinks;
		tabcontent = document.getElementsByClassName("tabcontent");
		for (i = 0; i < tabcontent.length; i++) {
			tabcontent[i].style.display = "none";
		}
		tablinks = document.getElementsByClassName("tablinks");
		for (i = 0; i < tablinks.length; i++) {
			tablinks[i].className = tablinks[i].className.replace(" active", "");
		}
		document.getElementById(movieDesc).style.display = "block";
		evt.currentTarget.className += " active";
	} else {}
}

function myShare() {
	document.getElementById("Share").classList.toggle("show");
}
window.onclick = function(event) {
	if (!event.target.matches('.wrapper__title-icon-share')) {
		var dropdowns = document.getElementsByClassName("wrapper__share");
		var i;
		for (i = 0; i < dropdowns.length; i++) {
			var openDropdown = dropdowns[i];
			if (openDropdown.classList.contains('show')) {
				openDropdown.classList.remove('show');
			}
		}
	}
}

function goHome() {
	window.location.href = "index.html"
}
$(document).ready(function() {
	//you can set this, as long as it's not greater than the slides length
	var show = 2;
	var w = $('#slider').width() / show;
	var l = $('.slide').length;
	$('.slide').width(w);
	$('#slide-container').width(w * l)

	function slider() {
		$('.slide:first-child').animate({
			marginLeft: -w
		}, 'slow', function() {
			$(this).appendTo($(this).parent()).css({
				marginLeft: 0
			});
		});
	}
	var timer = setInterval(slider, 2000);
	$('#slider').hover(function() {
		clearInterval(timer);
	}, function() {
		timer = setInterval(slider, 2000);
	});
});